package TestData;
use strict;
use warnings;

our %test = ( a => 1 );

our %required = (
    x       => 10,
    w       => 300,
    y       => 700,
    next_y  => 600,
    h       => 100,
    next_h  => 500,
);

1;
